(function(window, undefined) {

  var jimLinks = {
    "81297278-fda5-45f6-a32e-eba62efc9385" : {
      "Rectangle_6" : [
        "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"
      ],
      "Rectangle_17" : [
        "81297278-fda5-45f6-a32e-eba62efc9385"
      ],
      "Rectangle_19" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3" : {
      "Rectangle_6" : [
        "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"
      ],
      "Rectangle_17" : [
        "81297278-fda5-45f6-a32e-eba62efc9385"
      ],
      "Rectangle_19" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Button_1" : [
        "508648bf-4d05-4c98-8c23-f110664a866d"
      ],
      "Rectangle_6" : [
        "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"
      ],
      "Rectangle_17" : [
        "81297278-fda5-45f6-a32e-eba62efc9385"
      ],
      "Rectangle_19" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "508648bf-4d05-4c98-8c23-f110664a866d" : {
    }    
  }

  window.jimLinks = jimLinks;
})(window);