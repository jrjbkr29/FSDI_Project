var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1280" deviceHeight="800">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1625188746748.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1625188746748-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1625188746748-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-81297278-fda5-45f6-a32e-eba62efc9385" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Data_Hub" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/81297278-fda5-45f6-a32e-eba62efc9385-1625188746748.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/81297278-fda5-45f6-a32e-eba62efc9385-1625188746748-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/81297278-fda5-45f6-a32e-eba62efc9385-1625188746748-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Group_6" class="group firer ie-background commentable non-processed" customid="Group 4" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Group_1" datasizewidth="1024.0px" datasizeheight="770.0px" >\
          <div id="s-Rectangle_1" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_1"   datasizewidth="1024.0px" datasizeheight="770.0px" datasizewidthpx="1024.0" datasizeheightpx="770.0" dataX="134.0" dataY="189.2" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_1_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Text_1" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Text_1"   datasizewidth="229.0px" datasizeheight="50.0px" dataX="164.0" dataY="244.2" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_1_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Rectangle_2" class="pie rectangle manualfit firer mouseenter mouseleave mousedown mouseup commentable non-processed" customid="Rectangle_2"   datasizewidth="146.0px" datasizeheight="36.0px" datasizewidthpx="146.0" datasizeheightpx="36.0" dataX="778.0" dataY="251.2" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_2_0">Search</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Data_grid_1" summary="" class="pie datagrid horizontal firer ie-background commentable non-processed" customid="Data grid 4 1" items="3" size="0" childWidth="313.0" childHeight="155.0" hSpacing="12" vSpacing="44" datamaster="Search_Data" datasizewidth="987.0px" datasizeheight="641.0px" dataX="152.5" dataY="298.2" originalwidth="987.0px" originalheight="641.0px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
          	<div class="paddingLayer">\
              <table >\
              </table>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Input_3" class="pie text firer commentable non-processed" customid="Input"  datasizewidth="214.0px" datasizeheight="29.0px" dataX="539.0" dataY="251.4" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
      <div id="s-Paragraph_2" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Paragraph_2"   datasizewidth="485.0px" datasizeheight="90.0px" dataX="403.5" dataY="99.2" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0">Data Hub</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_3" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="233.5px" datasizeheight="27.0px" dataX="198.2" dataY="62.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_3_0">Space Simulation Lab</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_4" class="group firer ie-background commentable non-processed" customid="Group_2" datasizewidth="631.0px" datasizeheight="43.0px" >\
        <div id="s-Rectangle_6" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle_5"   datasizewidth="160.0px" datasizeheight="43.0px" datasizewidthpx="160.0" datasizeheightpx="43.0" dataX="192.0" dataY="52.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_6_0">Tasks</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_17" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle_6"   datasizewidth="160.0px" datasizeheight="43.0px" datasizewidthpx="160.0" datasizeheightpx="43.0" dataX="349.0" dataY="52.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_17_0">Data</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_18" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_7"   datasizewidth="160.0px" datasizeheight="43.0px" datasizewidthpx="160.0" datasizeheightpx="43.0" dataX="506.0" dataY="52.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_18_0">Reports</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_19" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle_8"   datasizewidth="160.0px" datasizeheight="43.0px" datasizewidthpx="160.0" datasizeheightpx="43.0" dataX="35.0" dataY="52.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_19_0">Home</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_5" class="group firer ie-background commentable non-processed" customid="Group_2" datasizewidth="496.0px" datasizeheight="46.0px" >\
        <div id="s-Input_19" class="pie text firer commentable non-processed" customid="Input_2"  datasizewidth="261.6px" datasizeheight="46.0px" dataX="767.0" dataY="50.0" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
\
        <div id="s-Image_4" class="pie image firer ie-background commentable non-processed" customid="Image_2"   datasizewidth="19.0px" datasizeheight="20.0px" dataX="777.0" dataY="62.0"   alt="image" systemName="./images/5a37d37b-a037-4f37-b18e-560467e9ad9c.svg" overlay="#CBCBCB">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="20px" version="1.1" viewBox="0 0 19 20" width="19px">\
            	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
            	    <title>Icon</title>\
            	    <desc>Created with Sketch.</desc>\
            	    <defs />\
            	    <g fill="none" fill-rule="evenodd" id="s-Image_4-Page-1" stroke="none" stroke-width="1">\
            	        <g fill="#B1B1B1" id="Header-#6" transform="translate(-1068.000000, -25.000000)">\
            	            <g id="s-Image_4-Search-" transform="translate(1068.000000, 17.000000)">\
            	                <path d="M12.939,16.271 C12.939,19.121 10.621,21.439 7.771,21.439 C4.921,21.439 2.584,19.121 2.584,16.271 C2.584,13.402 4.902,11.084 7.771,11.084 C10.621,11.084 12.939,13.421 12.939,16.271 L12.939,16.271 Z M14.174,20.66 C15.067,19.387 15.542,17.829 15.542,16.271 C15.542,11.977 12.065,8.5 7.771,8.5 C3.477,8.5 0,11.977 0,16.271 C0,20.565 3.477,24.042 7.771,24.042 C9.329,24.042 10.887,23.548 12.179,22.674 L17.005,27.5 L19,25.505 L14.174,20.66 Z" id="s-Image_4-Icon" style="fill:#CBCBCB !important;" />\
            	            </g>\
            	        </g>\
            	    </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Rectangle_20" class="pie rectangle manualfit firer mouseenter mouseleave mousedown mouseup commentable non-processed" customid="Rectangle_2"   datasizewidth="91.6px" datasizeheight="46.0px" datasizewidthpx="91.64515644752191" datasizeheightpx="46.0" dataX="1021.0" dataY="50.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_20_0">S E A R C H</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_35" class="pie image firer ie-background commentable non-processed" customid="Image_35"   datasizewidth="30.0px" datasizeheight="35.0px" dataX="1204.2" dataY="38.5"   alt="image" systemName="./images/16497628-9513-4d78-bd31-1670d8a0ef56.svg" overlay="#CBCBCB">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="20px" version="1.1" viewBox="0 0 17 20" width="17px">\
          	    <!-- Generator: Sketch 52.1 (67048) - http://www.bohemiancoding.com/sketch -->\
          	    <title>user</title>\
          	    <desc>Created with Sketch.</desc>\
          	    <g fill="none" fill-rule="evenodd" id="s-Image_35-Page-1" stroke="none" stroke-width="1">\
          	        <g fill="#666666" id="s-Image_35-user">\
          	            <path d="M8.63492063,0 C5.80790159,0 3.50793651,2.29996508 3.50793651,5.12698413 C3.50793651,7.95400317 5.80790159,10.2539683 8.63492063,10.2539683 C11.4619397,10.2539683 13.7619048,7.95400317 13.7619048,5.12698413 C13.7619048,2.29996508 11.4619397,0 8.63492063,0" id="s-Image_35-Fill-1" style="fill:#CBCBCB !important;" />\
          	            <path d="M9.63332578,11.4682653 L7.36665911,11.4682653 C5.40191244,11.4682653 3.55087689,12.2442836 2.15461022,13.65341 C0.765181333,15.0556274 -7.55555556e-06,16.9065514 -7.55555556e-06,18.8653527 C-7.55555556e-06,19.1764059 0.253708,19.4285827 0.566659111,19.4285827 L16.4333258,19.4285827 C16.7462769,19.4285827 16.9999924,19.1764059 16.9999924,18.8653527 C16.9999924,16.9065514 16.2348036,15.0556274 14.8453747,13.65341 C13.449108,12.2442836 11.5981102,11.4682653 9.63332578,11.4682653 Z" id="s-Image_35-Fill-3" style="fill:#CBCBCB !important;" />\
          	        </g>\
          	    </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Text_2" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_1"   datasizewidth="91.3px" datasizeheight="19.0px" dataX="1173.5" dataY="73.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_2_0">Not logged in</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_7" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Paragraph_3"   datasizewidth="597.0px" datasizeheight="47.0px" dataX="386.0" dataY="10.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_7_0">ORBIT SPACE SIMULATION LAB</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      <!-- START DATA VIEW TEMPLATES -->\
      <script type="text/x-jquery-tmpl" id="s-Data_grid_1-template">\
        <![CDATA[\
        <td>\
          <div id="s-Grid_cell_1" class="pie gridcell firer commentable non-processed " instance="{{=it.id}}" customid="" originalwidth="311.0px" originalheight="153.0px" >\
            <div class="cellContainerChild">\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="layout scrollable">\
                  <div class="paddingLayer">\
                    <div class="freeLayout">\
                    <div id="s-Input_1" class="pie text firer ie-background commentable non-processed" customid="Input 1"  datasizewidth="174.0px" datasizeheight="20.0px" dataX="66.0" dataY="16.0" ><div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text" name="99c56f14-b3c4-4af2-a287-8a18ba11505f" value="{{!it.userdata["99c56f14-b3c4-4af2-a287-8a18ba11505f"]}}" maxlength="100" readonly="readonly" tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
                    <div id="s-Input_2" class="pie text firer ie-background commentable non-processed" customid="Input 2"  datasizewidth="110.0px" datasizeheight="20.0px" dataX="66.0" dataY="41.5" ><div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text" name="2f4af3c4-b20c-48f2-a1ef-7619e6ebfe11" value="{{!it.userdata["2f4af3c4-b20c-48f2-a1ef-7619e6ebfe11"]}}" maxlength="100" readonly="readonly" tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
\
                      <div id="s-Input_5" class="pie checkbox firer commentable non-processed nonMobile" customid="Input 5" datasizewidth="13.0px" datasizeheight="13.0px" dataX="276.5" dataY="118.0" >\
                        <input class="checkBoxInput" type="checkbox"  name="0a9a22dd-3d6f-4dd9-9b4e-c385f9e9bfde" value="{{!it.userdata["0a9a22dd-3d6f-4dd9-9b4e-c385f9e9bfde"]}}" disabled="disabled" {{? jimData.isTrue(it.userdata["0a9a22dd-3d6f-4dd9-9b4e-c385f9e9bfde"]) }}checked="checked"{{?}} tabindex="-1" >\
                      </div>\
\
\
                    <div id="s-Group_12" class="group firer ie-background commentable non-processed" customid="Group 11" datasizewidth="0.0px" datasizeheight="0.0px" >\
                      <div id="shapewrapper-s-Ellipse_10" customid="Ellipse_1" class="shapewrapper shapewrapper-s-Ellipse_10 non-processed"   datasizewidth="37.0px" datasizeheight="37.0px" datasizewidthpx="37.0" datasizeheightpx="37.0" dataX="21.0" dataY="20.0" >\
                          <div class="backgroundLayer">\
                            <div class="colorLayer"></div>\
                            <div class="imageLayer"></div>\
                          </div>\
                          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_10" class="svgContainer" style="width:100%; height:100%;">\
                              <g>\
                                  <g clip-path="url(#clip-s-Ellipse_10)">\
                                          <ellipse id="s-Ellipse_10" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse_1" cx="18.5" cy="18.5" rx="18.5" ry="18.5">\
                                          </ellipse>\
                                  </g>\
                              </g>\
                              <defs>\
                                  <clipPath id="clip-s-Ellipse_10" class="clipPath">\
                                          <ellipse cx="18.5" cy="18.5" rx="18.5" ry="18.5">\
                                          </ellipse>\
                                  </clipPath>\
                              </defs>\
                          </svg>\
                          <div class="paddingLayer">\
                              <div id="shapert-s-Ellipse_10" class="content firer" >\
                                  <div class="valign">\
                                      <span id="rtr-s-Ellipse_10_0"></span>\
                                  </div>\
                              </div>\
                          </div>\
                      </div>\
\
                      <div id="s-Image_28" class="pie image lockV firer ie-background commentable non-processed" customid="Image_2"   datasizewidth="14.0px" datasizeheight="16.0px" dataX="32.0" dataY="30.0" aspectRatio="1.1428572"   alt="image" systemName="./images/718cc284-4558-40cd-b01f-a3c499f3309e.svg" overlay="#FFFFFF">\
                        <div class="borderLayer">\
                        	<div class="imageViewport">\
                          	<?xml version="1.0" encoding="UTF-8"?>\
                          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="20px" version="1.1" viewBox="0 0 17 20" width="17px">\
                          	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
                          	    <title>Page 1</title>\
                          	    <desc>Created with Sketch.</desc>\
                          	    <defs>\
                          	        <polygon id="s-Image_28-path-1" points="0 1.12646002e-05 16.9999924 1.12646002e-05 16.9999924 7.96031746 0 7.96031746" fill="#FFFFFF" jimofill=" " />\
                          	    </defs>\
                          	    <g fill="none" fill-rule="evenodd" id="s-Image_28-Page-1" stroke="none" stroke-width="1">\
                          	        <g id="Header-#4" transform="translate(-1082.000000, -25.000000)">\
                          	            <g id="s-Image_28-Page-1" transform="translate(1082.000000, 25.000000)">\
                          	                <path d="M8.63492063,0 C5.80790159,0 3.50793651,2.29996508 3.50793651,5.12698413 C3.50793651,7.95400317 5.80790159,10.2539683 8.63492063,10.2539683 C11.4619397,10.2539683 13.7619048,7.95400317 13.7619048,5.12698413 C13.7619048,2.29996508 11.4619397,0 8.63492063,0" fill="#666666" id="s-Image_28-Fill-1" style="fill:#FFFFFF !important;" />\
                          	                <g id="s-Image_28-Group-5" transform="translate(0.000000, 11.468254)">\
                          	                    <mask fill="white" id="s-Image_28-mask-2">\
                          	                        <use xlink:href="#s-Image_28-path-1" style="fill:#FFFFFF !important;" />\
                          	                    </mask>\
                          	                    <g id="s-Image_28-Clip-4" />\
                          	                    <path d="M9.63332578,1.12646002e-05 L7.36665911,1.12646002e-05 C5.40191244,1.12646002e-05 3.55087689,0.776029571 2.15461022,2.18515596 C0.765181333,3.58737339 -7.55555556e-06,5.43829739 -7.55555556e-06,7.39709872 C-7.55555556e-06,7.70815188 0.253708,7.96032872 0.566659111,7.96032872 L16.4333258,7.96032872 C16.7462769,7.96032872 16.9999924,7.70815188 16.9999924,7.39709872 C16.9999924,5.43829739 16.2348036,3.58737339 14.8453747,2.18515596 C13.449108,0.776029571 11.5981102,1.12646002e-05 9.63332578,1.12646002e-05 Z" fill="#666666" id="s-Image_28-Fill-3" mask="url(#s-Image_28-mask-2)" style="fill:#FFFFFF !important;" />\
                          	                </g>\
                          	            </g>\
                          	        </g>\
                          	    </g>\
                          	</svg>\
\
                          </div>\
                        </div>\
                      </div>\
\
                    </div>\
\
\
                    <div id="s-Image_29" class="pie image lockV firer ie-background commentable non-processed" customid="Image_1"   datasizewidth="26.0px" datasizeheight="5.0px" dataX="267.0" dataY="26.0" aspectRatio="0.1923077"   alt="image" systemName="./images/05e56d95-fb89-4a29-bde6-0bed3f4531ba.svg" overlay="#CBCBCB">\
                      <div class="borderLayer">\
                      	<div class="imageViewport">\
                        	<?xml version="1.0" encoding="UTF-8"?>\
                        	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="7px" version="1.1" viewBox="0 0 34 7" width="34px">\
                        	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
                        	    <title>Slider Horizontal Copy</title>\
                        	    <desc>Created with Sketch.</desc>\
                        	    <defs />\
                        	    <g fill="none" fill-rule="evenodd" id="s-Image_29-Page-1" stroke="none" stroke-width="1">\
                        	        <g fill="#282828" id="s-Image_29-Components" transform="translate(-664.000000, -1341.000000)">\
                        	            <g id="s-Image_29-Icons" transform="translate(603.000000, 1182.000000)">\
                        	                <g id="s-Image_29-Slider-Horizontal-Copy" transform="translate(61.000000, 159.000000)">\
                        	                    <circle cx="30.5" cy="3.5" id="s-Image_29-Dot-Filled" r="3.5" style="fill:#CBCBCB !important;" />\
                        	                    <circle cx="17.5" cy="3.5" id="s-Image_29-Dot-Filled" r="3.5" style="fill:#CBCBCB !important;" />\
                        	                    <circle cx="3.5" cy="3.5" id="s-Image_29-Dot-Filled" r="3.5" style="fill:#CBCBCB !important;" />\
                        	                </g>\
                        	            </g>\
                        	        </g>\
                        	    </g>\
                        	</svg>\
\
                        </div>\
                      </div>\
                    </div>\
\
\
                    <div id="s-Group_13" class="group firer ie-background commentable non-processed" customid="Group 13" datasizewidth="0.0px" datasizeheight="0.0px" >\
                      <div id="s-Rectangle_39" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_7"   datasizewidth="92.0px" datasizeheight="39.0px" datasizewidthpx="92.0" datasizeheightpx="39.0" dataX="21.0" dataY="97.0" >\
                        <div class="backgroundLayer">\
                          <div class="colorLayer"></div>\
                          <div class="imageLayer"></div>\
                        </div>\
                        <div class="borderLayer">\
                          <div class="paddingLayer">\
                            <div class="content">\
                              <div class="valign">\
                                <span id="rtr-s-Rectangle_39_0"></span><span id="rtr-s-Rectangle_39_1">L A B E L</span>\
                              </div>\
                            </div>\
                          </div>\
                        </div>\
                      </div>\
                      <div id="s-Rectangle_40" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_8"   datasizewidth="120.0px" datasizeheight="39.0px" datasizewidthpx="120.0" datasizeheightpx="39.0" dataX="126.0" dataY="97.0" >\
                        <div class="backgroundLayer">\
                          <div class="colorLayer"></div>\
                          <div class="imageLayer"></div>\
                        </div>\
                        <div class="borderLayer">\
                          <div class="paddingLayer">\
                            <div class="content">\
                              <div class="valign">\
                                <span id="rtr-s-Rectangle_40_0"></span><span id="rtr-s-Rectangle_40_1">L A B E L</span>\
                              </div>\
                            </div>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
\
                    </div>\
\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div> \
        </td>\
        ]]>\
      </script>\
      <!-- END DATA VIEW TEMPLATES -->\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;