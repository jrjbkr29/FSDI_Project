(function(window, undefined) {

  var jimLinks = {
    "81297278-fda5-45f6-a32e-eba62efc9385" : {
      "Rectangle_6" : [
        "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"
      ],
      "Rectangle_19" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3" : {
      "Rectangle_6" : [
        "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"
      ],
      "Rectangle_17" : [
        "81297278-fda5-45f6-a32e-eba62efc9385"
      ],
      "Rectangle_19" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Rectangle_6" : [
        "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"
      ],
      "Rectangle_17" : [
        "81297278-fda5-45f6-a32e-eba62efc9385"
      ],
      "Rectangle_19" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);