	window.widgets = {
		descriptionMap : widgetDescriptionMap = {},
		rootWidgetMap : widgetRootMap = {}
	};

	widgets.descriptionMap[["s-Paragraph_3", "81297278-fda5-45f6-a32e-eba62efc9385"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "81297278-fda5-45f6-a32e-eba62efc9385"]] = ["Text", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Rectangle_6", "81297278-fda5-45f6-a32e-eba62efc9385"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_6", "81297278-fda5-45f6-a32e-eba62efc9385"]] = ["Button light 2", "s-Rectangle_6"]; 

	widgets.descriptionMap[["s-Rectangle_17", "81297278-fda5-45f6-a32e-eba62efc9385"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_17", "81297278-fda5-45f6-a32e-eba62efc9385"]] = ["Button light 2", "s-Rectangle_17"]; 

	widgets.descriptionMap[["s-Rectangle_18", "81297278-fda5-45f6-a32e-eba62efc9385"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_18", "81297278-fda5-45f6-a32e-eba62efc9385"]] = ["Button light 2", "s-Rectangle_18"]; 

	widgets.descriptionMap[["s-Rectangle_19", "81297278-fda5-45f6-a32e-eba62efc9385"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_19", "81297278-fda5-45f6-a32e-eba62efc9385"]] = ["Button dark", "s-Rectangle_19"]; 

	widgets.descriptionMap[["s-Input_19", "81297278-fda5-45f6-a32e-eba62efc9385"]] = ""; 

			widgets.rootWidgetMap[["s-Input_19", "81297278-fda5-45f6-a32e-eba62efc9385"]] = ["Search field with button", "s-Group_5"]; 

	widgets.descriptionMap[["s-Image_4", "81297278-fda5-45f6-a32e-eba62efc9385"]] = ""; 

			widgets.rootWidgetMap[["s-Image_4", "81297278-fda5-45f6-a32e-eba62efc9385"]] = ["Zoom icon", "s-Image_4"]; 

	widgets.descriptionMap[["s-Rectangle_20", "81297278-fda5-45f6-a32e-eba62efc9385"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_20", "81297278-fda5-45f6-a32e-eba62efc9385"]] = ["Button dark", "s-Rectangle_20"]; 

	widgets.descriptionMap[["s-Image_35", "81297278-fda5-45f6-a32e-eba62efc9385"]] = ""; 

			widgets.rootWidgetMap[["s-Image_35", "81297278-fda5-45f6-a32e-eba62efc9385"]] = ["User icon", "s-Image_35"]; 

	widgets.descriptionMap[["s-Text_2", "81297278-fda5-45f6-a32e-eba62efc9385"]] = ""; 

			widgets.rootWidgetMap[["s-Text_2", "81297278-fda5-45f6-a32e-eba62efc9385"]] = ["Text", "s-Text_2"]; 

	widgets.descriptionMap[["s-Rectangle_1", "81297278-fda5-45f6-a32e-eba62efc9385"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "81297278-fda5-45f6-a32e-eba62efc9385"]] = ["Data grid 4", "s-Group_6"]; 

	widgets.descriptionMap[["s-Text_1", "81297278-fda5-45f6-a32e-eba62efc9385"]] = ""; 

			widgets.rootWidgetMap[["s-Text_1", "81297278-fda5-45f6-a32e-eba62efc9385"]] = ["Title 1", "s-Text_1"]; 

	widgets.descriptionMap[["s-Rectangle_2", "81297278-fda5-45f6-a32e-eba62efc9385"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "81297278-fda5-45f6-a32e-eba62efc9385"]] = ["Button dark", "s-Rectangle_2"]; 

	widgets.descriptionMap[["s-Data_grid_1", "81297278-fda5-45f6-a32e-eba62efc9385"]] = ""; 

			widgets.rootWidgetMap[["s-Data_grid_1", "81297278-fda5-45f6-a32e-eba62efc9385"]] = ["Data grid 4", "s-Group_6"]; 

	widgets.descriptionMap[["s-Input_1", "81297278-fda5-45f6-a32e-eba62efc9385"]] = ""; 

			widgets.rootWidgetMap[["s-Input_1", "81297278-fda5-45f6-a32e-eba62efc9385"]] = ["Data grid 4", "s-Group_6"]; 

	widgets.descriptionMap[["s-Input_2", "81297278-fda5-45f6-a32e-eba62efc9385"]] = ""; 

			widgets.rootWidgetMap[["s-Input_2", "81297278-fda5-45f6-a32e-eba62efc9385"]] = ["Data grid 4", "s-Group_6"]; 

	widgets.descriptionMap[["s-Input_5", "81297278-fda5-45f6-a32e-eba62efc9385"]] = ""; 

			widgets.rootWidgetMap[["s-Input_5", "81297278-fda5-45f6-a32e-eba62efc9385"]] = ["Data grid 4", "s-Group_6"]; 

	widgets.descriptionMap[["s-Ellipse_10", "81297278-fda5-45f6-a32e-eba62efc9385"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_10", "81297278-fda5-45f6-a32e-eba62efc9385"]] = ["Data grid 4", "s-Group_6"]; 

	widgets.descriptionMap[["s-Image_28", "81297278-fda5-45f6-a32e-eba62efc9385"]] = ""; 

			widgets.rootWidgetMap[["s-Image_28", "81297278-fda5-45f6-a32e-eba62efc9385"]] = ["User icon", "s-Image_28"]; 

	widgets.descriptionMap[["s-Image_29", "81297278-fda5-45f6-a32e-eba62efc9385"]] = ""; 

			widgets.rootWidgetMap[["s-Image_29", "81297278-fda5-45f6-a32e-eba62efc9385"]] = ["Menu dots", "s-Image_29"]; 

	widgets.descriptionMap[["s-Rectangle_39", "81297278-fda5-45f6-a32e-eba62efc9385"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_39", "81297278-fda5-45f6-a32e-eba62efc9385"]] = ["Data grid 4", "s-Group_6"]; 

	widgets.descriptionMap[["s-Rectangle_40", "81297278-fda5-45f6-a32e-eba62efc9385"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_40", "81297278-fda5-45f6-a32e-eba62efc9385"]] = ["Data grid 4", "s-Group_6"]; 

	widgets.descriptionMap[["s-Grid_cell_1", "81297278-fda5-45f6-a32e-eba62efc9385"]] = ""; 

			widgets.rootWidgetMap[["s-Grid_cell_1", "81297278-fda5-45f6-a32e-eba62efc9385"]] = ["Data grid 4", "s-Group_6"]; 

	widgets.descriptionMap[["s-Input_3", "81297278-fda5-45f6-a32e-eba62efc9385"]] = ""; 

			widgets.rootWidgetMap[["s-Input_3", "81297278-fda5-45f6-a32e-eba62efc9385"]] = ["Input Text Field", "s-Input_3"]; 

	widgets.descriptionMap[["s-Paragraph_2", "81297278-fda5-45f6-a32e-eba62efc9385"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "81297278-fda5-45f6-a32e-eba62efc9385"]] = ["h1", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Data_grid_3", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Data_grid_3", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Data grid 3", "s-Data_grid_3"]; 

	widgets.descriptionMap[["s-Rectangle_12", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_12", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Data grid 3", "s-Data_grid_3"]; 

	widgets.descriptionMap[["s-Ellipse_8", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_8", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Data grid 3", "s-Data_grid_3"]; 

	widgets.descriptionMap[["s-Input_11", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Input_11", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Data grid 3", "s-Data_grid_3"]; 

	widgets.descriptionMap[["s-Input_12", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Input_12", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Data grid 3", "s-Data_grid_3"]; 

	widgets.descriptionMap[["s-Panel_3", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_3", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Data grid 3", "s-Data_grid_3"]; 

	widgets.descriptionMap[["s-Rectangle_13", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_13", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Data grid 3", "s-Data_grid_3"]; 

	widgets.descriptionMap[["s-Line_8", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Line_8", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Data grid 3", "s-Data_grid_3"]; 

	widgets.descriptionMap[["s-Rectangle_14", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_14", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Data grid 3", "s-Data_grid_3"]; 

	widgets.descriptionMap[["s-Input_13", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Input_13", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Data grid 3", "s-Data_grid_3"]; 

	widgets.descriptionMap[["s-Input_14", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Input_14", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Data grid 3", "s-Data_grid_3"]; 

	widgets.descriptionMap[["s-Rectangle_15", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_15", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Data grid 3", "s-Data_grid_3"]; 

	widgets.descriptionMap[["s-Input_15", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Input_15", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Data grid 3", "s-Data_grid_3"]; 

	widgets.descriptionMap[["s-Input_16", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Input_16", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Data grid 3", "s-Data_grid_3"]; 

	widgets.descriptionMap[["s-Rectangle_16", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_16", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Data grid 3", "s-Data_grid_3"]; 

	widgets.descriptionMap[["s-Input_17", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Input_17", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Data grid 3", "s-Data_grid_3"]; 

	widgets.descriptionMap[["s-Input_18", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Input_18", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Data grid 3", "s-Data_grid_3"]; 

	widgets.descriptionMap[["s-Grid_cell_3", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Grid_cell_3", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Data grid 3", "s-Data_grid_3"]; 

	widgets.descriptionMap[["s-Rectangle_6", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_6", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Button light 2", "s-Rectangle_6"]; 

	widgets.descriptionMap[["s-Rectangle_17", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_17", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Button light 2", "s-Rectangle_17"]; 

	widgets.descriptionMap[["s-Rectangle_18", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_18", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Button light 2", "s-Rectangle_18"]; 

	widgets.descriptionMap[["s-Rectangle_19", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_19", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Button dark", "s-Rectangle_19"]; 

	widgets.descriptionMap[["s-Image_35", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Image_35", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["User icon", "s-Image_35"]; 

	widgets.descriptionMap[["s-Text_1", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Text_1", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Text", "s-Text_1"]; 

	widgets.descriptionMap[["s-Input_19", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Input_19", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Search field with button", "s-Group_5"]; 

	widgets.descriptionMap[["s-Image_2", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Zoom icon", "s-Image_2"]; 

	widgets.descriptionMap[["s-Rectangle_20", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_20", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Button dark", "s-Rectangle_20"]; 

	widgets.descriptionMap[["s-Rectangle_1", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Payment form 2", "s-Group_10"]; 

	widgets.descriptionMap[["s-Rectangle_21", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_21", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Button dark", "s-Rectangle_21"]; 

	widgets.descriptionMap[["s-Input_20", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Input_20", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Payment form 2", "s-Group_10"]; 

	widgets.descriptionMap[["s-Input_21", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Input_21", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Payment form 2", "s-Group_10"]; 

	widgets.descriptionMap[["s-Input_22", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Input_22", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Payment form 2", "s-Group_10"]; 

	widgets.descriptionMap[["s-Input_23", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Input_23", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Payment form 2", "s-Group_10"]; 

	widgets.descriptionMap[["s-Input_24", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Input_24", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Payment form 2", "s-Group_10"]; 

	widgets.descriptionMap[["s-Input_25", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Input_25", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Payment form 2", "s-Group_10"]; 

	widgets.descriptionMap[["s-Text_2", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Text_2", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Title 1", "s-Text_2"]; 

	widgets.descriptionMap[["s-Text_3", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Text_3", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Title 1", "s-Text_3"]; 

	widgets.descriptionMap[["s-Text_4", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Text_4", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Title 1", "s-Text_4"]; 

	widgets.descriptionMap[["s-Text_5", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Text_5", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Title 1", "s-Text_5"]; 

	widgets.descriptionMap[["s-Text_6", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Text_6", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Title 1", "s-Text_6"]; 

	widgets.descriptionMap[["s-Text_7", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Text_7", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Title 1", "s-Text_7"]; 

	widgets.descriptionMap[["s-Text_8", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Text_8", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Title 1", "s-Text_8"]; 

	widgets.descriptionMap[["s-Text_9", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Text_9", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Title 1", "s-Text_9"]; 

	widgets.descriptionMap[["s-Text_10", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Text_10", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Title 1", "s-Text_10"]; 

	widgets.descriptionMap[["s-Input_26", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Input_26", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Payment form 2", "s-Group_10"]; 

	widgets.descriptionMap[["s-Text_11", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Text_11", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Title 1", "s-Text_11"]; 

	widgets.descriptionMap[["s-Text_12", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Text_12", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Title 1", "s-Text_12"]; 

	widgets.descriptionMap[["s-Text_13", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Text_13", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Title 1", "s-Text_13"]; 

	widgets.descriptionMap[["s-Category_1", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Category_1", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Select drop down", "s-Category_1"]; 

	widgets.descriptionMap[["s-Rectangle_22", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_22", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Payment form 2", "s-Group_10"]; 

	widgets.descriptionMap[["s-Image_1", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Chev Down", "s-Image_1"]; 

	widgets.descriptionMap[["s-Rectangle_23", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_23", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Dropdown", "s-Group_6"]; 

	widgets.descriptionMap[["s-Rectangle_24", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_24", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Dropdown", "s-Group_6"]; 

	widgets.descriptionMap[["s-Rectangle_25", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_25", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Dropdown", "s-Group_6"]; 

	widgets.descriptionMap[["s-Rectangle_26", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_26", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Dropdown", "s-Group_6"]; 

	widgets.descriptionMap[["s-Input_27", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Input_27", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Input field", "s-Input_27"]; 

	widgets.descriptionMap[["s-Image_3", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Chev Down", "s-Image_3"]; 

	widgets.descriptionMap[["s-Rectangle_27", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_27", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Dropdown", "s-Group_8"]; 

	widgets.descriptionMap[["s-Rectangle_28", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_28", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Dropdown", "s-Group_8"]; 

	widgets.descriptionMap[["s-Rectangle_29", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_29", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Dropdown", "s-Group_8"]; 

	widgets.descriptionMap[["s-Rectangle_30", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_30", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Dropdown", "s-Group_8"]; 

	widgets.descriptionMap[["s-Input_28", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Input_28", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Input field", "s-Input_28"]; 

	widgets.descriptionMap[["s-Image_4", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ""; 

			widgets.rootWidgetMap[["s-Image_4", "4fd1c6b4-3cc6-460a-a1b1-6969b16178c3"]] = ["Chev Down", "s-Image_4"]; 

	widgets.descriptionMap[["s-Button_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Paragraph_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Text", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Rectangle_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Slider 1", "s-Group_1"]; 

	widgets.descriptionMap[["s-Ellipse_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Slider 1", "s-Group_1"]; 

	widgets.descriptionMap[["s-Ellipse_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Slider 1", "s-Group_1"]; 

	widgets.descriptionMap[["s-Ellipse_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Slider 1", "s-Group_1"]; 

	widgets.descriptionMap[["s-Text_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Text_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Slider 1", "s-Group_1"]; 

	widgets.descriptionMap[["s-Paragraph_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Slider 1", "s-Group_1"]; 

	widgets.descriptionMap[["s-Image_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Slider 1", "s-Group_1"]; 

	widgets.descriptionMap[["s-Image_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Slider 1", "s-Group_1"]; 

	widgets.descriptionMap[["s-Image_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Slider 1", "s-Group_1"]; 

	widgets.descriptionMap[["s-Paragraph_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Text", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Paragraph_4", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Text", "s-Paragraph_4"]; 

	widgets.descriptionMap[["s-Button_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Button_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Button", "s-Button_2"]; 

	widgets.descriptionMap[["s-Paragraph_5", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Text", "s-Paragraph_5"]; 

	widgets.descriptionMap[["s-Paragraph_6", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_6", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Paragraph", "s-Paragraph_6"]; 

	widgets.descriptionMap[["s-Rectangle_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Simple label", "s-Rectangle_2"]; 

	widgets.descriptionMap[["s-Rectangle_6", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_6", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Button light 2", "s-Rectangle_6"]; 

	widgets.descriptionMap[["s-Rectangle_17", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_17", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Button light 2", "s-Rectangle_17"]; 

	widgets.descriptionMap[["s-Rectangle_18", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_18", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Button light 2", "s-Rectangle_18"]; 

	widgets.descriptionMap[["s-Rectangle_19", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_19", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Button dark", "s-Rectangle_19"]; 

	widgets.descriptionMap[["s-Input_19", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Input_19", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Search field with button", "s-Group_5"]; 

	widgets.descriptionMap[["s-Image_4", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Image_4", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Zoom icon", "s-Image_4"]; 

	widgets.descriptionMap[["s-Rectangle_20", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_20", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Button dark", "s-Rectangle_20"]; 

	widgets.descriptionMap[["s-Image_35", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Image_35", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["User icon", "s-Image_35"]; 

	widgets.descriptionMap[["s-Text_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Text_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Text", "s-Text_2"]; 

	