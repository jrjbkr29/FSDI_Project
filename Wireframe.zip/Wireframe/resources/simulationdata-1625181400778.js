function initData() {
  jimData.datamasters["Tasks"] = [
    {
      "id": 1,
      "datamaster": "Tasks",
      "userdata": {
        "729db64a-a65a-49fd-8f58-2625ebfc518a": "Lorem ipsum",
        "b271e38c-eb70-46f3-8082-edff7536d739": "Lorem ipsum",
        "fe94679e-0df5-4b13-b902-a5a85f4e5028": "Lorem ipsum",
        "71a27aa9-b791-4f46-8853-1818af4d98be": "Lorem ipsum dolor sit amet",
        "198db131-b938-4e7e-8555-cf8d89c8b18b": "Lorem ipsum",
        "f46a6df4-62fb-41da-ad49-828b0c0c85bb": "Lorem ipsum dolor sit amet",
        "ce9b5f27-8527-4e48-a805-c2963a5a66a7": "Lorem ipsum",
        "58a21819-9128-4cc8-a78c-26658ca61280": "Lorem ipsum dolor sit amet"
      }
    },
    {
      "id": 2,
      "datamaster": "Tasks",
      "userdata": {
        "729db64a-a65a-49fd-8f58-2625ebfc518a": "Lorem ipsum",
        "b271e38c-eb70-46f3-8082-edff7536d739": "Lorem ipsum",
        "fe94679e-0df5-4b13-b902-a5a85f4e5028": "Lorem ipsum",
        "71a27aa9-b791-4f46-8853-1818af4d98be": "Lorem ipsum dolor sit amet",
        "198db131-b938-4e7e-8555-cf8d89c8b18b": "Lorem ipsum",
        "f46a6df4-62fb-41da-ad49-828b0c0c85bb": "Lorem ipsum dolor sit amet",
        "ce9b5f27-8527-4e48-a805-c2963a5a66a7": "Lorem ipsum",
        "58a21819-9128-4cc8-a78c-26658ca61280": "Lorem ipsum dolor sit amet"
      }
    },
    {
      "id": 3,
      "datamaster": "Tasks",
      "userdata": {
        "729db64a-a65a-49fd-8f58-2625ebfc518a": "Lorem ipsum",
        "b271e38c-eb70-46f3-8082-edff7536d739": "Lorem ipsum",
        "fe94679e-0df5-4b13-b902-a5a85f4e5028": "Lorem ipsum",
        "71a27aa9-b791-4f46-8853-1818af4d98be": "Lorem ipsum dolor sit amet",
        "198db131-b938-4e7e-8555-cf8d89c8b18b": "Lorem ipsum",
        "f46a6df4-62fb-41da-ad49-828b0c0c85bb": "Lorem ipsum dolor sit amet",
        "ce9b5f27-8527-4e48-a805-c2963a5a66a7": "Lorem ipsum",
        "58a21819-9128-4cc8-a78c-26658ca61280": "Lorem ipsum dolor sit amet"
      }
    },
    {
      "id": 4,
      "datamaster": "Tasks",
      "userdata": {
        "729db64a-a65a-49fd-8f58-2625ebfc518a": "Lorem ipsum",
        "b271e38c-eb70-46f3-8082-edff7536d739": "Lorem ipsum",
        "fe94679e-0df5-4b13-b902-a5a85f4e5028": "Lorem ipsum",
        "71a27aa9-b791-4f46-8853-1818af4d98be": "Lorem ipsum dolor sit amet",
        "198db131-b938-4e7e-8555-cf8d89c8b18b": "Lorem ipsum",
        "f46a6df4-62fb-41da-ad49-828b0c0c85bb": "Lorem ipsum dolor sit amet",
        "ce9b5f27-8527-4e48-a805-c2963a5a66a7": "Lorem ipsum",
        "58a21819-9128-4cc8-a78c-26658ca61280": "Lorem ipsum dolor sit amet"
      }
    },
    {
      "id": 5,
      "datamaster": "Tasks",
      "userdata": {
        "729db64a-a65a-49fd-8f58-2625ebfc518a": "Lorem ipsum",
        "b271e38c-eb70-46f3-8082-edff7536d739": "Lorem ipsum",
        "fe94679e-0df5-4b13-b902-a5a85f4e5028": "Lorem ipsum",
        "71a27aa9-b791-4f46-8853-1818af4d98be": "Lorem ipsum dolor sit amet",
        "198db131-b938-4e7e-8555-cf8d89c8b18b": "Lorem ipsum",
        "f46a6df4-62fb-41da-ad49-828b0c0c85bb": "Lorem ipsum dolor sit amet",
        "ce9b5f27-8527-4e48-a805-c2963a5a66a7": "Lorem ipsum",
        "58a21819-9128-4cc8-a78c-26658ca61280": "Lorem ipsum dolor sit amet"
      }
    },
    {
      "id": 6,
      "datamaster": "Tasks",
      "userdata": {
        "729db64a-a65a-49fd-8f58-2625ebfc518a": "Lorem ipsum",
        "b271e38c-eb70-46f3-8082-edff7536d739": "Lorem ipsum",
        "fe94679e-0df5-4b13-b902-a5a85f4e5028": "Lorem ipsum",
        "71a27aa9-b791-4f46-8853-1818af4d98be": "Lorem ipsum dolor sit amet",
        "198db131-b938-4e7e-8555-cf8d89c8b18b": "Lorem ipsum",
        "f46a6df4-62fb-41da-ad49-828b0c0c85bb": "Lorem ipsum dolor sit amet",
        "ce9b5f27-8527-4e48-a805-c2963a5a66a7": "Lorem ipsum",
        "58a21819-9128-4cc8-a78c-26658ca61280": "Lorem ipsum dolor sit amet"
      }
    }
  ];

  jimData.datamasters["Search_Data"] = [
    {
      "id": 1,
      "datamaster": "Search_Data",
      "userdata": {
        "99c56f14-b3c4-4af2-a287-8a18ba11505f": "Name Last name",
        "2f4af3c4-b20c-48f2-a1ef-7619e6ebfe11": "Lorem ipsum",
        "0a9a22dd-3d6f-4dd9-9b4e-c385f9e9bfde": "false"
      }
    },
    {
      "id": 2,
      "datamaster": "Search_Data",
      "userdata": {
        "99c56f14-b3c4-4af2-a287-8a18ba11505f": "Name Last name",
        "2f4af3c4-b20c-48f2-a1ef-7619e6ebfe11": "Lorem ipsum",
        "0a9a22dd-3d6f-4dd9-9b4e-c385f9e9bfde": "false"
      }
    },
    {
      "id": 3,
      "datamaster": "Search_Data",
      "userdata": {
        "99c56f14-b3c4-4af2-a287-8a18ba11505f": "Name Last name",
        "2f4af3c4-b20c-48f2-a1ef-7619e6ebfe11": "Lorem ipsum",
        "0a9a22dd-3d6f-4dd9-9b4e-c385f9e9bfde": "true"
      }
    },
    {
      "id": 4,
      "datamaster": "Search_Data",
      "userdata": {
        "99c56f14-b3c4-4af2-a287-8a18ba11505f": "Name Last name",
        "2f4af3c4-b20c-48f2-a1ef-7619e6ebfe11": "Lorem ipsum",
        "0a9a22dd-3d6f-4dd9-9b4e-c385f9e9bfde": "false"
      }
    },
    {
      "id": 5,
      "datamaster": "Search_Data",
      "userdata": {
        "99c56f14-b3c4-4af2-a287-8a18ba11505f": "Name Last name",
        "2f4af3c4-b20c-48f2-a1ef-7619e6ebfe11": "Lorem ipsum",
        "0a9a22dd-3d6f-4dd9-9b4e-c385f9e9bfde": "true"
      }
    },
    {
      "id": 6,
      "datamaster": "Search_Data",
      "userdata": {
        "99c56f14-b3c4-4af2-a287-8a18ba11505f": "Name Last name",
        "2f4af3c4-b20c-48f2-a1ef-7619e6ebfe11": "Lorem ipsum",
        "0a9a22dd-3d6f-4dd9-9b4e-c385f9e9bfde": "false"
      }
    },
    {
      "id": 7,
      "datamaster": "Search_Data",
      "userdata": {
        "99c56f14-b3c4-4af2-a287-8a18ba11505f": "Name Last name",
        "2f4af3c4-b20c-48f2-a1ef-7619e6ebfe11": "Lorem ipsum",
        "0a9a22dd-3d6f-4dd9-9b4e-c385f9e9bfde": "true"
      }
    },
    {
      "id": 8,
      "datamaster": "Search_Data",
      "userdata": {
        "99c56f14-b3c4-4af2-a287-8a18ba11505f": "Name Last name",
        "2f4af3c4-b20c-48f2-a1ef-7619e6ebfe11": "Lorem ipsum",
        "0a9a22dd-3d6f-4dd9-9b4e-c385f9e9bfde": "true"
      }
    },
    {
      "id": 9,
      "datamaster": "Search_Data",
      "userdata": {
        "99c56f14-b3c4-4af2-a287-8a18ba11505f": "Name Last name",
        "2f4af3c4-b20c-48f2-a1ef-7619e6ebfe11": "Lorem ipsum",
        "0a9a22dd-3d6f-4dd9-9b4e-c385f9e9bfde": "false"
      }
    }
  ];

  jimData.isInitialized = true;
}