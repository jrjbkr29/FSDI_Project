var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1280" deviceHeight="800">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1625188068944.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1625188068944-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-4fd1c6b4-3cc6-460a-a1b1-6969b16178c3" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="SPA_Tasks" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/4fd1c6b4-3cc6-460a-a1b1-6969b16178c3-1625188068944.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/4fd1c6b4-3cc6-460a-a1b1-6969b16178c3-1625188068944-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/4fd1c6b4-3cc6-460a-a1b1-6969b16178c3-1625188068944-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Data_grid_3" summary="" class="pie datagrid horizontal firer ie-background commentable non-processed" customid="Data grid 3 1" items="3" size="0" childWidth="351.6666666666668" childHeight="269.00000000000017" hSpacing="23" vSpacing="36" datamaster="Tasks" datasizewidth="1147.0px" datasizeheight="648.0px" dataX="52.0" dataY="103.0" originalwidth="1147.0000000000005px" originalheight="648.0000000000003px" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
        	<div class="paddingLayer">\
            <table >\
            </table>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_10" class="group firer ie-background commentable non-processed" customid="Group_1" datasizewidth="1024.0px" datasizeheight="735.0px" >\
        <div id="s-Rectangle_1" class="pie rectangle manualfit firer pageload commentable non-processed" customid="Rectangle_1"   datasizewidth="500.0px" datasizeheight="735.0px" datasizewidthpx="500.0" datasizeheightpx="735.0" dataX="-681.0" dataY="137.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_1_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_21" class="pie rectangle manualfit firer mouseenter mouseleave mousedown mouseup pageload commentable non-processed" customid="Rectangle_2"   datasizewidth="160.0px" datasizeheight="43.0px" datasizewidthpx="160.0" datasizeheightpx="43.0" dataX="-466.0" dataY="773.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_21_0">B U T T O N</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Input_20" class="pie text firer pageload commentable non-processed" customid="Input_1"  datasizewidth="224.1px" datasizeheight="52.0px" dataX="-661.0" dataY="290.0" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
        <div id="s-Input_21" class="pie text firer pageload commentable non-processed" customid="Input_2"  datasizewidth="224.1px" datasizeheight="52.0px" dataX="-661.0" dataY="409.0" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
        <div id="s-Input_22" class="pie number text firer pageload commentable non-processed" customid="Input_3"  datasizewidth="224.1px" datasizeheight="52.0px" dataX="-425.0" dataY="290.0" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="number"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
        <div id="s-Input_23" class="pie text firer pageload commentable non-processed" customid="Input_4"  datasizewidth="224.1px" datasizeheight="52.0px" dataX="-425.0" dataY="409.0" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
        <div id="s-Input_24" class="pie text firer pageload commentable non-processed" customid="Input_5"  datasizewidth="113.8px" datasizeheight="52.0px" dataX="-661.0" dataY="636.0" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
        <div id="s-Input_25" class="pie text firer pageload commentable non-processed" customid="Input_6"  datasizewidth="224.1px" datasizeheight="52.0px" dataX="-661.0" dataY="521.0" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
        <div id="s-Text_2" class="pie richtext autofit firer pageload ie-background commentable non-processed" customid="Text_1"   datasizewidth="65.1px" datasizeheight="18.0px" dataX="-661.0" dataY="263.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_2_0">R.E./P.O.C.</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_3" class="pie richtext autofit firer pageload ie-background commentable non-processed" customid="Text_2"   datasizewidth="100.6px" datasizeheight="18.0px" dataX="-661.0" dataY="382.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_3_0">Unit Description</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_4" class="pie richtext autofit firer pageload ie-background commentable non-processed" customid="Text_3"   datasizewidth="76.9px" datasizeheight="18.0px" dataX="-661.0" dataY="611.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_4_0">Assigned TO</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_5" class="pie richtext autofit firer pageload ie-background commentable non-processed" customid="Text_4"   datasizewidth="38.5px" datasizeheight="18.0px" dataX="-661.0" dataY="495.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_5_0">EMAIL</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_6" class="pie richtext autofit firer pageload ie-background commentable non-processed" customid="Text_5"   datasizewidth="73.2px" datasizeheight="18.0px" dataX="-425.0" dataY="263.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_6_0">Work Order</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_7" class="pie richtext autofit firer pageload ie-background commentable non-processed" customid="Text_6"   datasizewidth="89.6px" datasizeheight="18.0px" dataX="-425.0" dataY="382.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_7_0">Serial Number</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_8" class="pie richtext autofit firer pageload ie-background commentable non-processed" customid="Text_7"   datasizewidth="148.2px" datasizeheight="18.0px" dataX="-425.0" dataY="495.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_8_0">Part Number *Required</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_9" class="pie richtext autofit firer pageload ie-background commentable non-processed" customid="Text_8"   datasizewidth="221.1px" datasizeheight="29.0px" dataX="-661.0" dataY="191.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_9_0">Customer information</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_10" class="pie richtext autofit firer pageload ie-background commentable non-processed" customid="Text_9"   datasizewidth="166.3px" datasizeheight="29.0px" dataX="-425.0" dataY="191.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_10_0">Create New Task</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Input_26" class="pie number text firer pageload commentable non-processed" customid="Input_7"  datasizewidth="78.6px" datasizeheight="52.0px" dataX="-280.0" dataY="636.0" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="number"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
        <div id="s-Text_11" class="pie richtext autofit firer pageload ie-background commentable non-processed" customid="Text_10"   datasizewidth="38.7px" datasizeheight="18.0px" dataX="-280.0" dataY="611.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_11_0">Status</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_12" class="pie richtext autofit firer pageload ie-background commentable non-processed" customid="Text_11"   datasizewidth="84.5px" datasizeheight="18.0px" dataX="-425.0" dataY="611.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_12_0">ATP/QTP/DEV</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_13" class="pie richtext autofit firer pageload ie-background commentable non-processed" customid="Text_12"   datasizewidth="84.5px" datasizeheight="18.0px" dataX="-534.0" dataY="611.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_13_0">ATP/QTP/DEV</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Category_1" class="pie dropdown firer pageload commentable non-processed" customid="Category_1"    datasizewidth="224.1px" datasizeheight="52.0px" dataX="-425.0" dataY="521.0"  tabindex="-1"><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content icon"><div class="valign"><div class="value"></div></div></div></div></div><select id="s-Category_1-options" class="s-4fd1c6b4-3cc6-460a-a1b1-6969b16178c3 dropdown-options" ><option selected="selected" class="option"><br /></option>\
        <option  class="option">new value 1</option>\
        <option  class="option">new value 2</option>\
        <option  class="option">new value 3</option></select></div>\
        <div id="s-Rectangle_22" class="pie rectangle manualfit firer pageload commentable non-processed" customid="Rectangle_3"   datasizewidth="14.6px" datasizeheight="14.0px" datasizewidthpx="14.648437499999886" datasizeheightpx="14.0" dataX="-220.0" dataY="541.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_22_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Image_1" class="pie image firer click pageload ie-background commentable non-processed" customid="Image_1"   datasizewidth="23.0px" datasizeheight="14.0px" dataX="-220.0" dataY="541.0"   alt="image" systemName="./images/686fd253-7485-4e35-be64-86cc2cfbf0ec.svg" overlay="#CBCBCB">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="13px" version="1.1" viewBox="0 0 23 13" width="23px">\
            	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
            	    <title>Arrow Left</title>\
            	    <desc>Created with Sketch.</desc>\
            	    <defs />\
            	    <g fill="none" fill-rule="evenodd" id="s-Image_1-Page-1" stroke="none" stroke-width="1">\
            	        <g fill="#CBCBCB" id="s-Image_1-Components" transform="translate(-658.000000, -518.000000)">\
            	            <g id="s-Image_1-Inputs" transform="translate(100.000000, 498.000000)">\
            	                <g id="s-Image_1-Arrow-Left" transform="translate(569.500000, 26.000000) rotate(270.000000) translate(-569.500000, -26.000000) translate(562.500000, 14.500000)">\
            	                    <polyline points="1.7525625 0 0.8125 0.939714286 10.8265625 11.1878571 0.8125 21.1033214 1.8890625 22.1785714 13 11.2461786 1.7525625 0" transform="translate(6.906250, 11.089286) scale(-1, 1) translate(-6.906250, -11.089286) " style="fill:#CBCBCB !important;" />\
            	                </g>\
            	            </g>\
            	        </g>\
            	    </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
\
\
        <div id="s-Group_6" class="group firer ie-background commentable non-processed" customid="Group_2" datasizewidth="202.0px" datasizeheight="232.0px" >\
          <div id="s-Group_7" class="group firer ie-background commentable hidden non-processed" customid="Group_3" datasizewidth="202.0px" datasizeheight="181.0px" >\
            <div id="s-Rectangle_23" class="pie rectangle manualfit firer click pageload commentable non-processed" customid="Rectangle_4"   datasizewidth="98.6px" datasizeheight="46.0px" datasizewidthpx="98.6328125" datasizeheightpx="45.999999999999886" dataX="-534.0" dataY="687.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Rectangle_23_0">Select 1</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
            <div id="s-Rectangle_24" class="pie rectangle manualfit firer click pageload commentable non-processed" customid="Rectangle_5"   datasizewidth="98.6px" datasizeheight="46.0px" datasizewidthpx="98.6328125" datasizeheightpx="46.0" dataX="-534.0" dataY="732.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Rectangle_24_0">Select 2</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
            <div id="s-Rectangle_25" class="pie rectangle manualfit firer click pageload commentable non-processed" customid="Rectangle_6"   datasizewidth="98.6px" datasizeheight="46.0px" datasizewidthpx="98.6328125" datasizeheightpx="45.99999999999977" dataX="-534.0" dataY="777.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Rectangle_25_0">Select 3</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
            <div id="s-Rectangle_26" class="pie rectangle manualfit firer click pageload commentable non-processed" customid="Rectangle_7"   datasizewidth="98.6px" datasizeheight="46.0px" datasizewidthpx="98.6328125" datasizeheightpx="45.99999999999977" dataX="-534.0" dataY="822.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Rectangle_26_0">Select 4</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Input_27" class="pie text firer click pageload commentable non-processed" customid="Input_8"  datasizewidth="98.6px" datasizeheight="52.0px" dataX="-534.0" dataY="636.0" ><div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100" readonly="readonly" tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
\
          <div id="s-Image_3" class="pie image lockV firer click pageload ie-background commentable non-processed" customid="Image_2"   datasizewidth="10.3px" datasizeheight="5.4px" dataX="-454.0" dataY="654.0" aspectRatio="0.52380955"   alt="image" systemName="./images/9b04e1e0-da88-4c53-8869-50f718682271.svg" overlay="#CBCBCB">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="13px" version="1.1" viewBox="0 0 23 13" width="23px">\
              	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
              	    <title>Arrow Left</title>\
              	    <desc>Created with Sketch.</desc>\
              	    <defs />\
              	    <g fill="none" fill-rule="evenodd" id="s-Image_3-Page-1" stroke="none" stroke-width="1">\
              	        <g fill="#CBCBCB" id="s-Image_3-Components" transform="translate(-658.000000, -518.000000)">\
              	            <g id="s-Image_3-Inputs" transform="translate(100.000000, 498.000000)">\
              	                <g id="s-Image_3-Arrow-Left" transform="translate(569.500000, 26.000000) rotate(270.000000) translate(-569.500000, -26.000000) translate(562.500000, 14.500000)">\
              	                    <polyline points="1.7525625 0 0.8125 0.939714286 10.8265625 11.1878571 0.8125 21.1033214 1.8890625 22.1785714 13 11.2461786 1.7525625 0" transform="translate(6.906250, 11.089286) scale(-1, 1) translate(-6.906250, -11.089286) " style="fill:#CBCBCB !important;" />\
              	                </g>\
              	            </g>\
              	        </g>\
              	    </g>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
\
        </div>\
\
\
        <div id="s-Group_8" class="group firer ie-background commentable non-processed" customid="Group_4" datasizewidth="263.0px" datasizeheight="232.0px" >\
          <div id="s-Group_9" class="group firer ie-background commentable hidden non-processed" customid="Group_5" datasizewidth="263.0px" datasizeheight="181.0px" >\
            <div id="s-Rectangle_27" class="pie rectangle manualfit firer click pageload commentable non-processed" customid="Rectangle_8"   datasizewidth="128.4px" datasizeheight="46.0px" datasizewidthpx="128.41796875" datasizeheightpx="45.999999999999886" dataX="-425.0" dataY="687.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Rectangle_27_0">Select 1</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
            <div id="s-Rectangle_28" class="pie rectangle manualfit firer click pageload commentable non-processed" customid="Rectangle_9"   datasizewidth="128.4px" datasizeheight="46.0px" datasizewidthpx="128.41796875" datasizeheightpx="46.0" dataX="-425.0" dataY="732.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Rectangle_28_0">Select 2</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
            <div id="s-Rectangle_29" class="pie rectangle manualfit firer click pageload commentable non-processed" customid="Rectangle_10"   datasizewidth="128.4px" datasizeheight="46.0px" datasizewidthpx="128.41796875" datasizeheightpx="45.99999999999977" dataX="-425.0" dataY="777.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Rectangle_29_0">Select 3</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
            <div id="s-Rectangle_30" class="pie rectangle manualfit firer click pageload commentable non-processed" customid="Rectangle_11"   datasizewidth="128.4px" datasizeheight="46.0px" datasizewidthpx="128.41796875" datasizeheightpx="45.99999999999977" dataX="-425.0" dataY="822.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Rectangle_30_0">Select 4</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Input_28" class="pie text firer click pageload commentable non-processed" customid="Input_9"  datasizewidth="128.4px" datasizeheight="52.0px" dataX="-425.0" dataY="636.0" ><div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100" readonly="readonly" tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
\
          <div id="s-Image_4" class="pie image lockV firer click pageload ie-background commentable non-processed" customid="Image_3"   datasizewidth="10.3px" datasizeheight="5.4px" dataX="-321.0" dataY="654.0" aspectRatio="0.52380955"   alt="image" systemName="./images/d2eff47e-6bf7-4215-b6dc-c447ef256166.svg" overlay="#CBCBCB">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="13px" version="1.1" viewBox="0 0 23 13" width="23px">\
              	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
              	    <title>Arrow Left</title>\
              	    <desc>Created with Sketch.</desc>\
              	    <defs />\
              	    <g fill="none" fill-rule="evenodd" id="s-Image_4-Page-1" stroke="none" stroke-width="1">\
              	        <g fill="#CBCBCB" id="s-Image_4-Components" transform="translate(-658.000000, -518.000000)">\
              	            <g id="s-Image_4-Inputs" transform="translate(100.000000, 498.000000)">\
              	                <g id="s-Image_4-Arrow-Left" transform="translate(569.500000, 26.000000) rotate(270.000000) translate(-569.500000, -26.000000) translate(562.500000, 14.500000)">\
              	                    <polyline points="1.7525625 0 0.8125 0.939714286 10.8265625 11.1878571 0.8125 21.1033214 1.8890625 22.1785714 13 11.2461786 1.7525625 0" transform="translate(6.906250, 11.089286) scale(-1, 1) translate(-6.906250, -11.089286) " style="fill:#CBCBCB !important;" />\
              	                </g>\
              	            </g>\
              	        </g>\
              	    </g>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
\
        </div>\
\
      </div>\
\
      <div id="s-Paragraph_3" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="233.5px" datasizeheight="27.0px" dataX="188.2" dataY="52.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_3_0">Space Simulation Lab</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_4" class="group firer ie-background commentable non-processed" customid="Group_2" datasizewidth="631.0px" datasizeheight="43.0px" >\
        <div id="s-Rectangle_6" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle_5"   datasizewidth="160.0px" datasizeheight="43.0px" datasizewidthpx="160.0" datasizeheightpx="43.0" dataX="182.0" dataY="42.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_6_0">Tasks</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_17" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle_6"   datasizewidth="160.0px" datasizeheight="43.0px" datasizewidthpx="160.0" datasizeheightpx="43.0" dataX="339.0" dataY="42.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_17_0">Data</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_18" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_7"   datasizewidth="160.0px" datasizeheight="43.0px" datasizewidthpx="160.0" datasizeheightpx="43.0" dataX="496.0" dataY="42.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_18_0">Reports</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_19" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle_8"   datasizewidth="160.0px" datasizeheight="43.0px" datasizewidthpx="160.0" datasizeheightpx="43.0" dataX="25.0" dataY="42.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_19_0">Home</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_5" class="group firer ie-background commentable non-processed" customid="Group_2" datasizewidth="496.0px" datasizeheight="46.0px" >\
        <div id="s-Input_19" class="pie text firer commentable non-processed" customid="Input_2"  datasizewidth="261.6px" datasizeheight="46.0px" dataX="757.0" dataY="40.0" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
\
        <div id="s-Image_5" class="pie image firer ie-background commentable non-processed" customid="Image_2"   datasizewidth="19.0px" datasizeheight="20.0px" dataX="767.0" dataY="52.0"   alt="image" systemName="./images/77634313-0c07-4b72-807b-e11d8efcb1bd.svg" overlay="#CBCBCB">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="20px" version="1.1" viewBox="0 0 19 20" width="19px">\
            	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
            	    <title>Icon</title>\
            	    <desc>Created with Sketch.</desc>\
            	    <defs />\
            	    <g fill="none" fill-rule="evenodd" id="s-Image_5-Page-1" stroke="none" stroke-width="1">\
            	        <g fill="#B1B1B1" id="Header-#6" transform="translate(-1068.000000, -25.000000)">\
            	            <g id="s-Image_5-Search-" transform="translate(1068.000000, 17.000000)">\
            	                <path d="M12.939,16.271 C12.939,19.121 10.621,21.439 7.771,21.439 C4.921,21.439 2.584,19.121 2.584,16.271 C2.584,13.402 4.902,11.084 7.771,11.084 C10.621,11.084 12.939,13.421 12.939,16.271 L12.939,16.271 Z M14.174,20.66 C15.067,19.387 15.542,17.829 15.542,16.271 C15.542,11.977 12.065,8.5 7.771,8.5 C3.477,8.5 0,11.977 0,16.271 C0,20.565 3.477,24.042 7.771,24.042 C9.329,24.042 10.887,23.548 12.179,22.674 L17.005,27.5 L19,25.505 L14.174,20.66 Z" id="s-Image_5-Icon" style="fill:#CBCBCB !important;" />\
            	            </g>\
            	        </g>\
            	    </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Rectangle_20" class="pie rectangle manualfit firer mouseenter mouseleave mousedown mouseup commentable non-processed" customid="Rectangle_2"   datasizewidth="91.6px" datasizeheight="46.0px" datasizewidthpx="91.64515644752191" datasizeheightpx="46.0" dataX="1011.0" dataY="40.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_20_0">S E A R C H</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_35" class="pie image firer ie-background commentable non-processed" customid="Image_35"   datasizewidth="30.0px" datasizeheight="35.0px" dataX="1194.2" dataY="28.5"   alt="image" systemName="./images/a55cb61b-0d43-4ff0-881f-b76a1c6b2daa.svg" overlay="#CBCBCB">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="20px" version="1.1" viewBox="0 0 17 20" width="17px">\
          	    <!-- Generator: Sketch 52.1 (67048) - http://www.bohemiancoding.com/sketch -->\
          	    <title>user</title>\
          	    <desc>Created with Sketch.</desc>\
          	    <g fill="none" fill-rule="evenodd" id="s-Image_35-Page-1" stroke="none" stroke-width="1">\
          	        <g fill="#666666" id="s-Image_35-user">\
          	            <path d="M8.63492063,0 C5.80790159,0 3.50793651,2.29996508 3.50793651,5.12698413 C3.50793651,7.95400317 5.80790159,10.2539683 8.63492063,10.2539683 C11.4619397,10.2539683 13.7619048,7.95400317 13.7619048,5.12698413 C13.7619048,2.29996508 11.4619397,0 8.63492063,0" id="s-Image_35-Fill-1" style="fill:#CBCBCB !important;" />\
          	            <path d="M9.63332578,11.4682653 L7.36665911,11.4682653 C5.40191244,11.4682653 3.55087689,12.2442836 2.15461022,13.65341 C0.765181333,15.0556274 -7.55555556e-06,16.9065514 -7.55555556e-06,18.8653527 C-7.55555556e-06,19.1764059 0.253708,19.4285827 0.566659111,19.4285827 L16.4333258,19.4285827 C16.7462769,19.4285827 16.9999924,19.1764059 16.9999924,18.8653527 C16.9999924,16.9065514 16.2348036,15.0556274 14.8453747,13.65341 C13.449108,12.2442836 11.5981102,11.4682653 9.63332578,11.4682653 Z" id="s-Image_35-Fill-3" style="fill:#CBCBCB !important;" />\
          	        </g>\
          	    </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Text_14" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_1"   datasizewidth="91.3px" datasizeheight="19.0px" dataX="1163.5" dataY="63.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_14_0">Not logged in</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_7" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Paragraph_3"   datasizewidth="597.0px" datasizeheight="94.0px" dataX="376.0" dataY="-0.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_7_0">ORBIT SPACE SIMULATION LAB</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_22" class="pie image firer click ie-background commentable non-processed" customid="Image_22"   datasizewidth="25.0px" datasizeheight="18.0px" dataX="12.5" dataY="103.0"   alt="image" systemName="./images/28d9853c-cf97-47ac-a8ee-4e9d1602774e.svg" overlay="#CBCBCB">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="18px" version="1.1" viewBox="0 0 25 18" width="25px">\
          	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
          	    <title>Menu Burger Icon</title>\
          	    <desc>Created with Sketch.</desc>\
          	    <defs />\
          	    <g fill="none" fill-rule="evenodd" id="s-Image_22-Page-1" stroke="none" stroke-width="1">\
          	        <g fill="#333333" id="Header-#2" transform="translate(-120.000000, -26.000000)">\
          	            <g id="s-Image_22-Top">\
          	                <path d="M145,26 L145,28 L120,28 L120,26 L145,26 Z M145,42 L145,44 L120,44 L120,42 L145,42 Z M145,34 L145,36 L120,36 L120,34 L145,34 Z" id="s-Image_22-Menu-Burger-Icon" style="fill:#CBCBCB !important;" />\
          	            </g>\
          	        </g>\
          	    </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
      </div>\
\
      <!-- START DATA VIEW TEMPLATES -->\
      <script type="text/x-jquery-tmpl" id="s-Data_grid_3-template">\
        <![CDATA[\
        <td>\
          <div id="s-Grid_cell_3" class="pie gridcell firer commentable non-processed " instance="{{=it.id}}" customid="" originalwidth="349.6666666666668px" originalheight="267.00000000000017px" >\
            <div class="cellContainerChild">\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="layout scrollable">\
                  <div class="paddingLayer">\
                    <table class="layout" summary="">\
                      <tr>\
                        <td class="layout vertical insertionpoint verticalalign Grid_cell_3 Data_grid_3" valign="top" align="left" hSpacing="0" vSpacing="0"><div id="s-Rectangle_12" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 7"   datasizewidth="105.0px" datasizeheight="25.0px" datasizewidthpx="105.0" datasizeheightpx="25.0" dataX="0.0" dataY="0.0" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                        <div class="paddingLayer">\
                          <div class="content">\
                            <div class="valign">\
                              <span id="rtr-s-Rectangle_12_0"></span>\
                            </div>\
                          </div>\
                        </div>\
                      </div>\
                    </div><div id="s-Dynamic_Panel_3" class="pie dynamicpanel firer ie-background commentable non-processed" customid="Dynamic Panel 1" datasizewidth="255.0px" datasizeheight="64.0px" dataX="0.0" dataY="0.0" >\
                      <div id="s-Panel_3" class="pie panel default firer ie-background commentable non-processed" customid="Panel 1"  datasizewidth="255.0px" datasizeheight="64.0px" >\
                        <div class="backgroundLayer">\
                          <div class="colorLayer"></div>\
                          <div class="imageLayer"></div>\
                        </div>\
                        <div class="borderLayer">\
                        	<div class="layoutWrapper scrollable">\
                        	  <div class="paddingLayer">\
                              <div class="left ghostHLayout">\
                              <table class="layout" summary="">\
                                <tr>\
                                  <td class="layout horizontal insertionpoint verticalalign Panel_3 Dynamic_Panel_3" valign="middle" align="left" hSpacing="11" vSpacing="0"><div id="shapewrapper-s-Ellipse_8" customid="Ellipse_1" class="shapewrapper shapewrapper-s-Ellipse_8 non-processed"   datasizewidth="54.0px" datasizeheight="54.0px" datasizewidthpx="54.0" datasizeheightpx="54.0" dataX="0.0" dataY="0.0" >\
                                  <div class="backgroundLayer">\
                                    <div class="colorLayer"></div>\
                                    <div class="imageLayer"></div>\
                                  </div>\
                                  <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_8" class="svgContainer" style="width:100%; height:100%;">\
                                      <g>\
                                          <g clip-path="url(#clip-s-Ellipse_8)">\
                                                  <ellipse id="s-Ellipse_8" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse_1" cx="27.0" cy="27.0" rx="27.0" ry="27.0">\
                                                  </ellipse>\
                                          </g>\
                                      </g>\
                                      <defs>\
                                          <clipPath id="clip-s-Ellipse_8" class="clipPath">\
                                                  <ellipse cx="27.0" cy="27.0" rx="27.0" ry="27.0">\
                                                  </ellipse>\
                                          </clipPath>\
                                      </defs>\
                                  </svg>\
                                  <div class="paddingLayer">\
                                      <div id="shapert-s-Ellipse_8" class="content firer" >\
                                          <div class="valign">\
                                              <span id="rtr-s-Ellipse_8_0"></span>\
                                          </div>\
                                      </div>\
                                  </div>\
                              </div><div class="relativeLayoutWrapper s-Group_3 "><div class="relativeLayoutWrapperResponsive">\
                              <div id="s-Group_3" class="group firer ie-background commentable non-processed" customid="Group 1" datasizewidth="0.0px" datasizeheight="0.0px" >\
                                <div id="s-Input_11" class="pie text firer ie-background commentable non-processed" customid="Input 1"  datasizewidth="229.0px" datasizeheight="33.0px" dataX="0.0" dataY="43.0" ><div class="backgroundLayer">\
                                  <div class="colorLayer"></div>\
                                  <div class="imageLayer"></div>\
                                </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text" name="729db64a-a65a-49fd-8f58-2625ebfc518a" value="{{!it.userdata["729db64a-a65a-49fd-8f58-2625ebfc518a"]}}" maxlength="100" readonly="readonly" tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
                                <div id="s-Input_12" class="pie text firer ie-background commentable non-processed" customid="Input 2"  datasizewidth="189.0px" datasizeheight="20.0px" dataX="0.0" dataY="74.0" ><div class="backgroundLayer">\
                                  <div class="colorLayer"></div>\
                                  <div class="imageLayer"></div>\
                                </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text" name="b271e38c-eb70-46f3-8082-edff7536d739" value="{{!it.userdata["b271e38c-eb70-46f3-8082-edff7536d739"]}}" maxlength="100" readonly="readonly" tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
                              </div>\
                              </div></div></td> \
                                </tr>\
                              </table>\
                              </div>\
\
                            </div>\
                          </div>\
                        </div>\
                      </div>\
                    </div><div id="s-Rectangle_13" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 7"   datasizewidth="105.0px" datasizeheight="23.0px" datasizewidthpx="105.0" datasizeheightpx="23.0" dataX="0.0" dataY="0.0" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                        <div class="paddingLayer">\
                          <div class="content">\
                            <div class="valign">\
                              <span id="rtr-s-Rectangle_13_0"></span>\
                            </div>\
                          </div>\
                        </div>\
                      </div>\
                    </div><div id="s-Line_8" class="pie path firer ie-background commentable non-processed" customid="Line_1"   datasizewidth="252.0px" datasizeheight="3.0px" dataX="64.5" dataY="149.5"  >\
                      <div class="borderLayer">\
                      	<div class="imageViewport">\
                        	<?xml version="1.0" encoding="UTF-8"?>\
                        	<svg xmlns="http://www.w3.org/2000/svg" width="251.0" height="2.0" viewBox="64.5 149.5 251.0 2.0">\
                        	  <g>\
                        	    <defs>\
                        	      <path id="s-Line_8-4fd1c" d="M65.0 150.5 L315.0 150.5 "></path>\
                        	    </defs>\
                        	    <g>\
                        	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Line_8-4fd1c" fill="none" stroke-width="1" stroke="#DDDDDD" stroke-linecap="butt" filter="none"></use>\
                        	    </g>\
                        	  </g>\
                        	</svg>\
\
                        </div>\
                      </div>\
                    </div><div id="s-Rectangle_14" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 7"   datasizewidth="105.0px" datasizeheight="23.0px" datasizewidthpx="105.00000000000007" datasizeheightpx="23.000000000000057" dataX="0.0" dataY="0.0" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                        <div class="paddingLayer">\
                          <div class="content">\
                            <div class="valign">\
                              <span id="rtr-s-Rectangle_14_0"></span>\
                            </div>\
                          </div>\
                        </div>\
                      </div>\
                    </div><div id="s-Input_13" class="pie text firer ie-background commentable non-processed" customid="Input 3"  datasizewidth="235.0px" datasizeheight="20.0px" dataX="0.0" dataY="0.0" ><div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text" name="fe94679e-0df5-4b13-b902-a5a85f4e5028" value="{{!it.userdata["fe94679e-0df5-4b13-b902-a5a85f4e5028"]}}" maxlength="100" readonly="readonly" tabindex="-1" placeholder=""/></div></div>  </div></div></div><div id="s-Input_14" class="pie text firer ie-background commentable non-processed" customid="Input 4"  datasizewidth="243.0px" datasizeheight="20.0px" dataX="0.0" dataY="0.0" ><div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text" name="71a27aa9-b791-4f46-8853-1818af4d98be" value="{{!it.userdata["71a27aa9-b791-4f46-8853-1818af4d98be"]}}" maxlength="100" readonly="readonly" tabindex="-1" placeholder=""/></div></div>  </div></div></div><div id="s-Rectangle_15" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 7"   datasizewidth="105.0px" datasizeheight="27.0px" datasizewidthpx="105.00000000000018" datasizeheightpx="27.000000000000085" dataX="0.0" dataY="0.0" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                        <div class="paddingLayer">\
                          <div class="content">\
                            <div class="valign">\
                              <span id="rtr-s-Rectangle_15_0"></span>\
                            </div>\
                          </div>\
                        </div>\
                      </div>\
                    </div><div id="s-Input_15" class="pie text firer ie-background commentable non-processed" customid="Input 5"  datasizewidth="235.0px" datasizeheight="20.0px" dataX="0.0" dataY="0.0" ><div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text" name="198db131-b938-4e7e-8555-cf8d89c8b18b" value="{{!it.userdata["198db131-b938-4e7e-8555-cf8d89c8b18b"]}}" maxlength="100" readonly="readonly" tabindex="-1" placeholder=""/></div></div>  </div></div></div><div id="s-Input_16" class="pie text firer ie-background commentable non-processed" customid="Input 6"  datasizewidth="235.0px" datasizeheight="20.0px" dataX="0.0" dataY="0.0" ><div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text" name="f46a6df4-62fb-41da-ad49-828b0c0c85bb" value="{{!it.userdata["f46a6df4-62fb-41da-ad49-828b0c0c85bb"]}}" maxlength="100" readonly="readonly" tabindex="-1" placeholder=""/></div></div>  </div></div></div><div id="s-Rectangle_16" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 7"   datasizewidth="105.0px" datasizeheight="27.0px" datasizewidthpx="105.00000000000018" datasizeheightpx="27.000000000000085" dataX="10.0" dataY="10.0" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                        <div class="paddingLayer">\
                          <div class="content">\
                            <div class="valign">\
                              <span id="rtr-s-Rectangle_16_0"></span>\
                            </div>\
                          </div>\
                        </div>\
                      </div>\
                    </div><div id="s-Input_17" class="pie text firer ie-background commentable non-processed" customid="Input 7"  datasizewidth="235.0px" datasizeheight="20.0px" dataX="0.0" dataY="0.0" ><div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text" name="ce9b5f27-8527-4e48-a805-c2963a5a66a7" value="{{!it.userdata["ce9b5f27-8527-4e48-a805-c2963a5a66a7"]}}" maxlength="100" readonly="readonly" tabindex="-1" placeholder=""/></div></div>  </div></div></div><div id="s-Input_18" class="pie text firer ie-background commentable non-processed" customid="Input 8"  datasizewidth="236.0px" datasizeheight="20.0px" dataX="0.0" dataY="0.0" ><div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text" name="58a21819-9128-4cc8-a78c-26658ca61280" value="{{!it.userdata["58a21819-9128-4cc8-a78c-26658ca61280"]}}" maxlength="100" readonly="readonly" tabindex="-1" placeholder=""/></div></div>  </div></div></div></td> \
                      </tr>\
                    </table>\
\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div> \
        </td>\
        ]]>\
      </script>\
      <!-- END DATA VIEW TEMPLATES -->\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;