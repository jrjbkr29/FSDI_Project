var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1280" deviceHeight="800">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1625188068944.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1625188068944-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-508648bf-4d05-4c98-8c23-f110664a866d" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Form" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/508648bf-4d05-4c98-8c23-f110664a866d-1625188068944.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/508648bf-4d05-4c98-8c23-f110664a866d-1625188068944-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/508648bf-4d05-4c98-8c23-f110664a866d-1625188068944-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Group_10" class="group firer ie-background commentable non-processed" customid="Group_1" datasizewidth="1024.0px" datasizeheight="735.0px" >\
        <div id="s-Rectangle_1" class="pie rectangle manualfit firer pageload commentable non-processed" customid="Rectangle_1"   datasizewidth="500.0px" datasizeheight="735.0px" datasizewidthpx="500.0" datasizeheightpx="735.0" dataX="390.0" dataY="65.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_1_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_21" class="pie rectangle manualfit firer mouseenter mouseleave mousedown mouseup pageload commentable non-processed" customid="Rectangle_2"   datasizewidth="160.0px" datasizeheight="43.0px" datasizewidthpx="160.0" datasizeheightpx="43.0" dataX="605.0" dataY="701.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_21_0">B U T T O N</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Input_20" class="pie text firer pageload commentable non-processed" customid="Input_1"  datasizewidth="224.1px" datasizeheight="52.0px" dataX="410.0" dataY="218.0" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
        <div id="s-Input_21" class="pie text firer pageload commentable non-processed" customid="Input_2"  datasizewidth="224.1px" datasizeheight="52.0px" dataX="410.0" dataY="337.0" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
        <div id="s-Input_22" class="pie number text firer pageload commentable non-processed" customid="Input_3"  datasizewidth="224.1px" datasizeheight="52.0px" dataX="646.0" dataY="218.0" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="number"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
        <div id="s-Input_23" class="pie text firer pageload commentable non-processed" customid="Input_4"  datasizewidth="224.1px" datasizeheight="52.0px" dataX="646.0" dataY="337.0" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
        <div id="s-Input_24" class="pie text firer pageload commentable non-processed" customid="Input_5"  datasizewidth="113.8px" datasizeheight="52.0px" dataX="410.0" dataY="564.0" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
        <div id="s-Input_25" class="pie text firer pageload commentable non-processed" customid="Input_6"  datasizewidth="224.1px" datasizeheight="52.0px" dataX="410.0" dataY="449.0" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
        <div id="s-Text_2" class="pie richtext autofit firer pageload ie-background commentable non-processed" customid="Text_1"   datasizewidth="65.1px" datasizeheight="18.0px" dataX="410.0" dataY="191.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_2_0">R.E./P.O.C.</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_3" class="pie richtext autofit firer pageload ie-background commentable non-processed" customid="Text_2"   datasizewidth="100.6px" datasizeheight="18.0px" dataX="410.0" dataY="310.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_3_0">Unit Description</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_4" class="pie richtext autofit firer pageload ie-background commentable non-processed" customid="Text_3"   datasizewidth="76.9px" datasizeheight="18.0px" dataX="410.0" dataY="539.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_4_0">Assigned TO</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_5" class="pie richtext autofit firer pageload ie-background commentable non-processed" customid="Text_4"   datasizewidth="38.5px" datasizeheight="18.0px" dataX="410.0" dataY="423.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_5_0">EMAIL</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_6" class="pie richtext autofit firer pageload ie-background commentable non-processed" customid="Text_5"   datasizewidth="73.2px" datasizeheight="18.0px" dataX="646.0" dataY="191.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_6_0">Work Order</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_7" class="pie richtext autofit firer pageload ie-background commentable non-processed" customid="Text_6"   datasizewidth="89.6px" datasizeheight="18.0px" dataX="646.0" dataY="310.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_7_0">Serial Number</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_8" class="pie richtext autofit firer pageload ie-background commentable non-processed" customid="Text_7"   datasizewidth="148.2px" datasizeheight="18.0px" dataX="646.0" dataY="423.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_8_0">Part Number *Required</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_9" class="pie richtext autofit firer pageload ie-background commentable non-processed" customid="Text_8"   datasizewidth="221.1px" datasizeheight="29.0px" dataX="410.0" dataY="119.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_9_0">Customer information</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_10" class="pie richtext autofit firer pageload ie-background commentable non-processed" customid="Text_9"   datasizewidth="166.3px" datasizeheight="29.0px" dataX="646.0" dataY="119.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_10_0">Create New Task</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Input_26" class="pie number text firer pageload commentable non-processed" customid="Input_7"  datasizewidth="78.6px" datasizeheight="52.0px" dataX="791.0" dataY="564.0" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="number"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
        <div id="s-Text_11" class="pie richtext autofit firer pageload ie-background commentable non-processed" customid="Text_10"   datasizewidth="38.7px" datasizeheight="18.0px" dataX="791.0" dataY="539.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_11_0">Status</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_12" class="pie richtext autofit firer pageload ie-background commentable non-processed" customid="Text_11"   datasizewidth="84.5px" datasizeheight="18.0px" dataX="646.0" dataY="539.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_12_0">ATP/QTP/DEV</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_13" class="pie richtext autofit firer pageload ie-background commentable non-processed" customid="Text_12"   datasizewidth="84.5px" datasizeheight="18.0px" dataX="537.0" dataY="539.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_13_0">ATP/QTP/DEV</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Category_1" class="pie dropdown firer pageload commentable non-processed" customid="Category_1"    datasizewidth="224.1px" datasizeheight="52.0px" dataX="646.0" dataY="449.0"  tabindex="-1"><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content icon"><div class="valign"><div class="value"></div></div></div></div></div><select id="s-Category_1-options" class="s-508648bf-4d05-4c98-8c23-f110664a866d dropdown-options" ><option selected="selected" class="option"><br /></option>\
        <option  class="option">new value 1</option>\
        <option  class="option">new value 2</option>\
        <option  class="option">new value 3</option></select></div>\
        <div id="s-Rectangle_22" class="pie rectangle manualfit firer pageload commentable non-processed" customid="Rectangle_3"   datasizewidth="14.6px" datasizeheight="14.0px" datasizewidthpx="14.648437499999886" datasizeheightpx="14.0" dataX="851.0" dataY="469.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_22_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Image_1" class="pie image firer click pageload ie-background commentable non-processed" customid="Image_1"   datasizewidth="23.0px" datasizeheight="14.0px" dataX="851.0" dataY="469.0"   alt="image" systemName="./images/901eb26f-7c89-4dae-8834-774628f248e7.svg" overlay="#CBCBCB">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="13px" version="1.1" viewBox="0 0 23 13" width="23px">\
            	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
            	    <title>Arrow Left</title>\
            	    <desc>Created with Sketch.</desc>\
            	    <defs />\
            	    <g fill="none" fill-rule="evenodd" id="s-Image_1-Page-1" stroke="none" stroke-width="1">\
            	        <g fill="#CBCBCB" id="s-Image_1-Components" transform="translate(-658.000000, -518.000000)">\
            	            <g id="s-Image_1-Inputs" transform="translate(100.000000, 498.000000)">\
            	                <g id="s-Image_1-Arrow-Left" transform="translate(569.500000, 26.000000) rotate(270.000000) translate(-569.500000, -26.000000) translate(562.500000, 14.500000)">\
            	                    <polyline points="1.7525625 0 0.8125 0.939714286 10.8265625 11.1878571 0.8125 21.1033214 1.8890625 22.1785714 13 11.2461786 1.7525625 0" transform="translate(6.906250, 11.089286) scale(-1, 1) translate(-6.906250, -11.089286) " style="fill:#CBCBCB !important;" />\
            	                </g>\
            	            </g>\
            	        </g>\
            	    </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
\
\
        <div id="s-Group_6" class="group firer ie-background commentable non-processed" customid="Group_2" datasizewidth="202.0px" datasizeheight="232.0px" >\
          <div id="s-Group_7" class="group firer ie-background commentable hidden non-processed" customid="Group_3" datasizewidth="202.0px" datasizeheight="181.0px" >\
            <div id="s-Rectangle_23" class="pie rectangle manualfit firer click pageload commentable non-processed" customid="Rectangle_4"   datasizewidth="98.6px" datasizeheight="46.0px" datasizewidthpx="98.6328125" datasizeheightpx="45.999999999999886" dataX="537.0" dataY="615.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Rectangle_23_0">Select 1</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
            <div id="s-Rectangle_24" class="pie rectangle manualfit firer click pageload commentable non-processed" customid="Rectangle_5"   datasizewidth="98.6px" datasizeheight="46.0px" datasizewidthpx="98.6328125" datasizeheightpx="46.0" dataX="537.0" dataY="660.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Rectangle_24_0">Select 2</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
            <div id="s-Rectangle_25" class="pie rectangle manualfit firer click pageload commentable non-processed" customid="Rectangle_6"   datasizewidth="98.6px" datasizeheight="46.0px" datasizewidthpx="98.6328125" datasizeheightpx="45.99999999999977" dataX="537.0" dataY="705.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Rectangle_25_0">Select 3</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
            <div id="s-Rectangle_26" class="pie rectangle manualfit firer click pageload commentable non-processed" customid="Rectangle_7"   datasizewidth="98.6px" datasizeheight="46.0px" datasizewidthpx="98.6328125" datasizeheightpx="45.99999999999977" dataX="537.0" dataY="750.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Rectangle_26_0">Select 4</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Input_27" class="pie text firer click pageload commentable non-processed" customid="Input_8"  datasizewidth="98.6px" datasizeheight="52.0px" dataX="537.0" dataY="564.0" ><div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100" readonly="readonly" tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
\
          <div id="s-Image_3" class="pie image lockV firer click pageload ie-background commentable non-processed" customid="Image_2"   datasizewidth="10.3px" datasizeheight="5.4px" dataX="617.0" dataY="582.0" aspectRatio="0.52380955"   alt="image" systemName="./images/d9a4d77a-c69e-4679-bc45-a641da07f6ee.svg" overlay="#CBCBCB">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="13px" version="1.1" viewBox="0 0 23 13" width="23px">\
              	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
              	    <title>Arrow Left</title>\
              	    <desc>Created with Sketch.</desc>\
              	    <defs />\
              	    <g fill="none" fill-rule="evenodd" id="s-Image_3-Page-1" stroke="none" stroke-width="1">\
              	        <g fill="#CBCBCB" id="s-Image_3-Components" transform="translate(-658.000000, -518.000000)">\
              	            <g id="s-Image_3-Inputs" transform="translate(100.000000, 498.000000)">\
              	                <g id="s-Image_3-Arrow-Left" transform="translate(569.500000, 26.000000) rotate(270.000000) translate(-569.500000, -26.000000) translate(562.500000, 14.500000)">\
              	                    <polyline points="1.7525625 0 0.8125 0.939714286 10.8265625 11.1878571 0.8125 21.1033214 1.8890625 22.1785714 13 11.2461786 1.7525625 0" transform="translate(6.906250, 11.089286) scale(-1, 1) translate(-6.906250, -11.089286) " style="fill:#CBCBCB !important;" />\
              	                </g>\
              	            </g>\
              	        </g>\
              	    </g>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
\
        </div>\
\
\
        <div id="s-Group_8" class="group firer ie-background commentable non-processed" customid="Group_4" datasizewidth="263.0px" datasizeheight="232.0px" >\
          <div id="s-Group_9" class="group firer ie-background commentable hidden non-processed" customid="Group_5" datasizewidth="263.0px" datasizeheight="181.0px" >\
            <div id="s-Rectangle_27" class="pie rectangle manualfit firer click pageload commentable non-processed" customid="Rectangle_8"   datasizewidth="128.4px" datasizeheight="46.0px" datasizewidthpx="128.41796875" datasizeheightpx="45.999999999999886" dataX="646.0" dataY="615.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Rectangle_27_0">Select 1</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
            <div id="s-Rectangle_28" class="pie rectangle manualfit firer click pageload commentable non-processed" customid="Rectangle_9"   datasizewidth="128.4px" datasizeheight="46.0px" datasizewidthpx="128.41796875" datasizeheightpx="46.0" dataX="646.0" dataY="660.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Rectangle_28_0">Select 2</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
            <div id="s-Rectangle_29" class="pie rectangle manualfit firer click pageload commentable non-processed" customid="Rectangle_10"   datasizewidth="128.4px" datasizeheight="46.0px" datasizewidthpx="128.41796875" datasizeheightpx="45.99999999999977" dataX="646.0" dataY="705.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Rectangle_29_0">Select 3</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
            <div id="s-Rectangle_30" class="pie rectangle manualfit firer click pageload commentable non-processed" customid="Rectangle_11"   datasizewidth="128.4px" datasizeheight="46.0px" datasizewidthpx="128.41796875" datasizeheightpx="45.99999999999977" dataX="646.0" dataY="750.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Rectangle_30_0">Select 4</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Input_28" class="pie text firer click pageload commentable non-processed" customid="Input_9"  datasizewidth="128.4px" datasizeheight="52.0px" dataX="646.0" dataY="564.0" ><div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100" readonly="readonly" tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
\
          <div id="s-Image_4" class="pie image lockV firer click pageload ie-background commentable non-processed" customid="Image_3"   datasizewidth="10.3px" datasizeheight="5.4px" dataX="750.0" dataY="582.0" aspectRatio="0.52380955"   alt="image" systemName="./images/10f29c4d-3a5b-41de-b494-21903f6d5472.svg" overlay="#CBCBCB">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="13px" version="1.1" viewBox="0 0 23 13" width="23px">\
              	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
              	    <title>Arrow Left</title>\
              	    <desc>Created with Sketch.</desc>\
              	    <defs />\
              	    <g fill="none" fill-rule="evenodd" id="s-Image_4-Page-1" stroke="none" stroke-width="1">\
              	        <g fill="#CBCBCB" id="s-Image_4-Components" transform="translate(-658.000000, -518.000000)">\
              	            <g id="s-Image_4-Inputs" transform="translate(100.000000, 498.000000)">\
              	                <g id="s-Image_4-Arrow-Left" transform="translate(569.500000, 26.000000) rotate(270.000000) translate(-569.500000, -26.000000) translate(562.500000, 14.500000)">\
              	                    <polyline points="1.7525625 0 0.8125 0.939714286 10.8265625 11.1878571 0.8125 21.1033214 1.8890625 22.1785714 13 11.2461786 1.7525625 0" transform="translate(6.906250, 11.089286) scale(-1, 1) translate(-6.906250, -11.089286) " style="fill:#CBCBCB !important;" />\
              	                </g>\
              	            </g>\
              	        </g>\
              	    </g>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
\
        </div>\
\
      </div>\
\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;